import React from 'react';
import { motion } from 'framer-motion';
import { useCountdown } from '../hooks/useCountdown';
import { LAUNCH_DATE } from '../data/constants';

const Hero: React.FC = () => {
  const timeLeft = useCountdown(LAUNCH_DATE);

  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="min-h-screen bg-gradient-to-br from-zooOrange-light via-white to-zooGreen-light relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 text-6xl opacity-20 animate-float">🦁</div>
        <div className="absolute top-40 right-20 text-4xl opacity-20 animate-float" style={{ animationDelay: '1s' }}>🐘</div>
        <div className="absolute bottom-40 left-20 text-5xl opacity-20 animate-float" style={{ animationDelay: '2s' }}>🐅</div>
        <div className="absolute bottom-20 right-10 text-3xl opacity-20 animate-float" style={{ animationDelay: '0.5s' }}>🦓</div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center min-h-screen">
        <div className="text-center w-full">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8"
          >
            <div className="text-8xl mb-4 animate-bounce-slow">🦁</div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-montserrat font-bold text-zooDark mb-4">
              Welcome to the
              <span className="text-zooOrange block">Wild Side of Crypto</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-700 font-poppins max-w-3xl mx-auto">
              Join the ZooriseCoin revolution on Solana - where community meets wild gains!
            </p>
          </motion.div>

          {/* Countdown Timer */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-8"
          >
            <h3 className="text-2xl font-montserrat font-semibold text-zooDark mb-4">
              🚀 Launch Countdown
            </h3>
            <div className="flex justify-center space-x-4">
              {[
                { label: 'Days', value: timeLeft.days },
                { label: 'Hours', value: timeLeft.hours },
                { label: 'Minutes', value: timeLeft.minutes },
                { label: 'Seconds', value: timeLeft.seconds },
              ].map((unit, index) => (
                <motion.div
                  key={unit.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  className="bg-white rounded-lg shadow-lg p-4 min-w-[80px]"
                >
                  <div className="text-2xl md:text-3xl font-montserrat font-bold text-zooOrange">
                    {unit.value.toString().padStart(2, '0')}
                  </div>
                  <div className="text-sm text-gray-600 font-poppins">{unit.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <a
              href="https://t.me/zoorisecoin"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-zooOrange text-white px-8 py-4 rounded-full font-montserrat font-semibold text-lg hover:bg-zooOrange-dark transition-all duration-300 hover:scale-105 shadow-lg"
            >
              🚀 Join Our Pack
            </a>
            <button
              onClick={scrollToAbout}
              className="border-2 border-zooOrange text-zooOrange px-8 py-4 rounded-full font-montserrat font-semibold text-lg hover:bg-zooOrange hover:text-white transition-all duration-300 hover:scale-105"
            >
              🦁 Learn More
            </button>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-12 flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <div className="bg-white rounded-full px-6 py-3 shadow-md">
              <span className="text-zooGreen font-montserrat font-semibold">
                🚀 Launching on Pumpfun
              </span>
            </div>
            <div className="bg-white rounded-full px-6 py-3 shadow-md">
              <span className="text-zooGreen font-montserrat font-semibold">
                ⚡ Solana Powered
              </span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;